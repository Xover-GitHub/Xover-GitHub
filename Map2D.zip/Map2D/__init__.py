class Map:
    def __init__(self, x: int, y: int, null_point='0'):
        self.x = x
        self.y = y
        self.null_point = null_point
        self.map = []
        self.objects = []
        self.arrays = []
        self.groups = []

    def update(self):
        self.map = []
        for size1 in range(self.y):
            self.map.append([])
            for size2 in range(self.x):
                self.map[size1].append(self.null_point)

        for obj in self.objects:
            self.map[obj.y-1][obj.x-1] = obj.index

        for arr in self.arrays:
            for cur in arr.xys:
                self.map[cur[1]-1][cur[0]-1] = arr.index

    def visualize(self):
        self.update()
        output = ''
        for string1 in self.map:
            for string2 in string1:
                output+=string2
            output += '\n'
        print(output+'\n')

    def get_object_by_index(self, index: str):
        returning = []
        for obj in self.objects:
            if obj.index == index:
                returning.append(obj)
        return returning

    def get_object_by_x(self, x: int):
        returning = []
        for obj in self.objects:
            if obj.x == x:
                returning.append(obj)
        return returning

    def get_object_by_y(self, y: int):
        returning = []
        for obj in self.objects:
            if obj.y == y:
                returning.append(obj)
        return returning

    def get_array_by_index(self, index: str):
        returning = []
        for arr in self.arrays:
            if arr.index == index:
                returning.append(arr)
        return returning


class Object_Once:
    def __init__(self, index: str):
        if len(index) > 1:
            exit("Wrong ID type, ID must be 1 character length")
        else:
            self.index = index
        self.x = 1
        self.y = 1
        self.map = None
        self.groups = []
        self.recents = (1, 1)

    def place(self, x: int, y: int, placing: Map):
        self.x = x
        self.y = y
        self.map = placing
        try:
            self.map.objects.append(self)
        except:
            exit("map doesn't exist, or type incorrect")

    def remove_object(self):
        self.map.objects.remove(self)

    def undo(self):
        self.x = self.recents[0]
        self.y = self.recents[1]

    def move(self, new_x=None, new_y=None):
        self.recents = (self.x, self.y)
        if new_x is not None:
            self.x = new_x
        if new_y is not None:
            self.y = new_y

        if self.x > self.map.x or self.x < 1 or self.y > self.map.y or self.y < 1:
            self.undo()


class Object_Array:
    def __init__(self, index: str):
        if len(index) > 1:
            exit("Wrong ID type, ID must be 1 character length")
        else:
            self.index = index
        self.xys = [[1, 1], [2, 2]]
        self.map = None
        self.groups = []
        self.recents = [[1, 1], [2, 2]]

    def place(self, xys: list, placing: Map):
        self.xys = xys
        self.map = placing
        try:
            self.map.arrays.append(self)
        except:
            exit("map doesn't exist, or type incorrect")

    def remove_array(self):
        self.map.arrays.remove(self)

    def undo(self):
        self.xys = self.recents

    def move(self, plus_x=None, plus_y=None):
        self.recents = self.xys
        if plus_x is not None:
            for cur in self.xys:
                cur[0] += plus_x
        if plus_y is not None:
            for cur in self.xys:
                cur[1] += plus_y

        for cur in self.xys:
            if cur[0] > self.map.x or cur[0] < 1 or cur[1] > self.map.y or cur[1] < 1:
                self.undo()
                break