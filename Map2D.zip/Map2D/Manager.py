import Map2D
from Map2D import Advanced


def collision_obj_to_obj(objects: list):
    target = (objects[0].x, objects[0].y)
    targetmap = objects[0].map
    num = 1
    for cur in objects:
        if num == len(objects):
            return True
        if (cur.x, cur.y) == target and cur.map == targetmap:
            num += 1
    if num != len(objects):
        return False


def collision_obj_to_array(obj: Map2D.Object_Once, array: Map2D.Object_Array):
    a = False
    for cur in array.xys:
        if [obj.x, obj.y] == cur:
            a = True
            return True
    if not a:
        return False


def collision_groups_objs(groups: list):
    a = False
    for cur in groups:
        for cur1 in cur.objects:
            for i in cur.objects.remove(cur1):
                if [cur1.x, cur1.y] == [i.x, i.y]:
                    cur.objects.append(cur1)
                    a = True
                    return True
            cur.objects.append(cur1)
    if not a:
        return False


def collision_obj_to_group_arrays(obj: Map2D.Object_Once, group: Advanced.Group_Arrays):
    a = False
    for cur in group.arrays:
        for cur1 in cur.xys:
            if [obj.x, obj.y] == cur1:
                a = True
                return True
    if not a:
        return False


def collision_obj_to_group_objs(obj: Map2D.Object_Once, group: Advanced.Group_Onces):
    a = False
    for cur in group.objects:
        if [obj.x, obj.y] == [cur.x, cur.y]:
            a = True
            return True
    if not a:
        return False


class MCOC:
    def __init__(self, object: Map2D.Object_Once, w='w', a='a', s='s', d='d', amount=1):
        self.object = object
        self.w = w
        self.a = a
        self.s = s
        self.d = d
        self.amount = amount

    def call(self):
        print(f"({self.w}, {self.a}, {self.s}, {self.d})")
        chosen = str(input('>'))
        if chosen == self.w:
            self.object.move(new_y=self.object.y - self.amount)
        elif chosen == self.a:
            self.object.move(self.object.x - self.amount)
        elif chosen == self.s:
            self.object.move(new_y=self.object.y + self.amount)
        elif chosen == self.d:
            self.object.move(self.object.x + self.amount)
        else:
            print("wrong")