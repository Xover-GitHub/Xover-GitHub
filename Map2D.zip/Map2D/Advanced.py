import Map2D


class Group_Onces:
    def __init__(self, objects: list, placing: Map2D.Map):
        self.objects = objects
        self.map = placing
        self.map.groups.append(self)
        for cur in objects:
            if cur.map != self.map:
                exit("Mapping error")

    def move(self, plus_x=None, plus_y=None):
        for cur in self.objects:
            cur.move(cur.x+plus_x, cur.y+plus_y)

    def remove_group(self):
        self.map.groups.remove(self)
        self.objects = []


class Group_Arrays:
    def __init__(self, arrays: list, placing: Map2D.Map):
        self.arrays = arrays
        self.map = placing
        self.map.groups.append(self)
        for cur in arrays:
            if cur.map != self.map:
                exit("Mapping error")

    def move(self, plus_x=None, plus_y=None):
        for cur in self.arrays:
            cur.move(plus_x, plus_y)

    def remove_group(self):
        self.map.groups.remove(self)
        self.arrays = []